Android Studio'da kotlin kullanılarak geliştirilmiştir. Veriler Firebase kullanılarak depolanmıştır.

<div style="display: flex; justify-content: space-between;">
    <img src="1.png" alt="Resim 1" style="width: 15%;">
    <img src="2.png" alt="Resim 2" style="width: 15%;">
    <img src="3.png" alt="Resim 3" style="width: 15%;">
    <img src="4.png" alt="Resim 4" style="width: 15%;">
    <img src="5.png" alt="Resim 5" style="width: 15%;">
    <img src="6.png" alt="Resim 6" style="width: 15%;">
</div>
