package com.example.petcare

data class EventsData(val EventId: String, var Event:String )
