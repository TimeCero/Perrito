package com.example.petcare

data class ToDoData(val TaskId: String, var Task: String)
//Task id push() ile task'e atadigimiz random id. Task var olarak tanimlandi cunku editlenebilir olmali
